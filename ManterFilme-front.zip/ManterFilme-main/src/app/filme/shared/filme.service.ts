import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';
import { Filme } from './filme'

@Injectable({
  providedIn: 'root'
})
export class FilmeService {
  urlBackend: string = "http://localhost:8081"

  constructor(private http: HttpClient) { }

  public getFilmes(): Observable<Filme[]> {
    return this.http.get<Filme[]>(this.urlBackend+"/filme/");
  }

  public salvar(filme: Filme): Observable<Filme>{
    if(!filme.idFilme){
      return this.http.post<Filme>(this.urlBackend+"/filme/",filme); //Adcionar
    }else{
      return this.http.patch<Filme>(this.urlBackend+"/filme/"+filme.titulo, filme); //Editar
    }
  }

  public getById(id: number): Observable<Filme>{ // Buscar por id
    return this.http.get<Filme>(this.urlBackend+"/filme/"+id);
  }

  public getByTitulo(titulo: string): Observable<Filme>{ // Buscar pelo titulo
    return this.http.get<Filme>(this.urlBackend+"/filme/"+titulo);
  }

  public getByDiretor(diretor: string): Observable<Filme>{ // Buscar pelo titulo
    return this.http.get<Filme>(this.urlBackend+"/filme/diretor/"+diretor);
  }

  public remover(titulo: string): Observable<Filme>{
    return this.http.delete<Filme>(this.urlBackend+"/filme/"+titulo);
  }
}
