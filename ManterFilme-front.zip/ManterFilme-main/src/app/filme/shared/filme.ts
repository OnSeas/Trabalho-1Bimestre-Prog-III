export class Filme {
    
    idFilme!: number;
	titulo!: string;
	diretor!: string;
    dataLancamento!: string;
    duracao!: number;
}
