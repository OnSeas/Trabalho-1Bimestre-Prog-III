import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Filme } from '../shared/filme';
import { FilmeService } from '../shared/filme.service';

@Component({
  selector: 'app-filme-form',
  templateUrl: './filme-form.component.html',
  styleUrls: ['./filme-form.component.css']
})
export class FilmeFormComponent implements OnInit {
filme: Filme = new Filme;
  constructor(private filmeService: FilmeService,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit(): void {
    const titulo = this.route.snapshot.paramMap.get('titulo'); //pegar na rota atual o prametro especificado na rota
    if(titulo){
      this.filmeService.getByTitulo((titulo)).subscribe( (filme) => {
        if(filme){
          this.filme = filme;
        }
      }, erro => {
        alert("Erro ao buscar o filme "+titulo);
      });
    }
  }

  public salvar(filme: Filme){
    let acao="criado";

    if(filme.idFilme){
      acao = "alterado";
    }

    this.filmeService.salvar(filme).subscribe((filme) =>{
      console.log(filme);
      alert("Filme "+acao+" com sucesso!");
      this.router.navigate(['filme'])
    }, erro =>{
      alert(erro?.error?.message);
      console.log(erro);
    })
  }

}
