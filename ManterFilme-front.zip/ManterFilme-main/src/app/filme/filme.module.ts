import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FilmeComponent } from './filme.component';
import { FilmeFormComponent } from './filme-form/filme-form.component';
import { FilmeListComponent } from './filme-list/filme-list.component';
import { RouterModule } from '@angular/router';
import { FilmeRoutes } from './filme.routing';
import { FormsModule } from '@angular/forms';



@NgModule({
  declarations: [
    FilmeComponent,
    FilmeFormComponent,
    FilmeListComponent
  ],
  imports: [
    FormsModule,
    CommonModule,
    RouterModule.forChild(FilmeRoutes)
  ]
})
export class FilmeModule { }
