import { Component, OnInit } from '@angular/core';
import { Filme } from '../shared/filme';
import { FilmeService } from '../shared/filme.service';

@Component({
  selector: 'app-filme-list',
  templateUrl: './filme-list.component.html',
  styleUrls: ['./filme-list.component.css']
})
export class FilmeListComponent implements OnInit {
  filmes: Filme[] = [];

  constructor(private filmeService: FilmeService) { }

  ngOnInit(): void {
    this.filmeService.getFilmes().subscribe((filmes:Filme[]) =>{
      console.log("Filme", filmes);
      this.filmes = filmes;
    })
  }

  confirmaRemocao(filme: Filme){
    let mensagem = "Deseja remover o filme: "+filme.titulo+ ", Diretor"+filme.diretor + ", Data lançamento: "+filme.dataLancamento+"?";
    if(confirm(mensagem)){
      this.filmeService.remover(filme.titulo).subscribe( (filme)=>{
        let filmeIdx = this.filmes.findIndex( (value) => value.titulo == filme.titulo);
        this.filmes.splice(filmeIdx, 1);
        alert("o Filme foi removido com sucesso!!");
      }, erro => {
        alert("Erro ao excluir o filme. Mensagem: "+erro?.error?.message);
      });
    }
  }

}
