import { Routes } from "@angular/router";
import { FilmeFormComponent } from "./filme-form/filme-form.component";
import { FilmeListComponent } from "./filme-list/filme-list.component";
import { FilmeComponent } from "./filme.component";

export const FilmeRoutes: Routes = [
  {
    path: "filme",
    component: FilmeComponent,
    children: [
      {
        path: "",
        component: FilmeListComponent
      },
      {
        path: "novo",
        component: FilmeFormComponent
      },
      {
        path: "editar/:titulo",
        component: FilmeFormComponent
      }
    ]
  },
];
